# OmniFile F3.1 — Testing Report

## Executed checks

| Check | Result | Evidence / limitation |
|---|---|---|
| Kotlin compile of validator | PASS | Compiled `ApktoolZipPathValidator.kt` with installed `kotlinc`. |
| Validator path harness | PASS | Accepted a safe nested path; rejected 8 malicious variants (empty, absolute, drive-prefixed, backslash, dot-segment, traversal, repeated separator); rejected a symlink escape. |
| APKTool engine compile + execution harness | PASS | Compiled the changed engine and validator with minimal Android/Engine API/coroutine stubs; valid ZIP decoded; `../../` and Windows backslash traversal archives rejected before output directory creation. |
| Android Gradle unit tests | BLOCKED | `bash ./gradlew :engines:apktool:testDebugUnitTest :app:testDebugUnitTest --offline --no-daemon` attempted to download Gradle 8.10.2 and failed with `UnknownHostException: services.gradle.org`. |
| Device/emulator test | NOT RUN | Android SDK/ADB/device runtime unavailable in this environment. |

## Important qualification

The standalone Kotlin harness validates the changed path-validation and decode logic, but it is not a substitute for the real Android Gradle test task, Android SDK compilation, or device testing. The new JUnit regression tests are committed in the checkpoint source but could not be run through Gradle here.

## Build environment observations

- Java runtime available: OpenJDK 21.0.12.
- The project targets Java 17.
- Direct `./gradlew` invocation returned `Permission denied`; invoking the wrapper through `bash` reached the wrapper but could not download the required Gradle distribution due network/DNS unavailability.
