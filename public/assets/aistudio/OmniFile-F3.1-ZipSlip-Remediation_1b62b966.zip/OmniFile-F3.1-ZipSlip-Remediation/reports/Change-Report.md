# OmniFile F3.1 — P0 Zip Slip Remediation

**Status:** PARTIAL — source remediation implemented; Android Gradle verification blocked by environment.

## Scope

Exactly three source files changed; no unrelated modules or product architecture were changed.

1. `engines/apktool/src/main/java/com/omnifile/engines/apktool/ApktoolZipPathValidator.kt` — new strict ZIP entry path validator. Rejects empty paths, NUL, absolute paths, drive prefixes, backslashes, traversal/dot segments, empty segments, colon/alternate-stream segments, and excessive path/segment lengths. Resolves canonical paths and rejects paths outside the destination root, including pre-existing symlink escapes.
2. `engines/apktool/src/main/java/com/omnifile/engines/apktool/ApktoolEngine.kt` — preflights every central-directory entry with `ZipFile` before creating the output directory or writing data; validates again immediately before each write; returns a failure result for unsafe or unreadable archives.
3. `app/src/test/java/com/omnifile/app/EngineIntegrationTest.kt` — adds regressions for `../../` traversal and Windows backslash traversal, asserting rejection before output creation.

## Safety behavior

- A malicious later ZIP entry is discovered during preflight before any earlier safe-looking entry is extracted.
- The extraction path is canonicalized against the selected root.
- Existing symlink components that resolve outside the root are rejected.
- The original APK is read-only and is not modified by this remediation.

## Files changed

3 files total: 1 new Kotlin source file and 2 modified Kotlin files.
