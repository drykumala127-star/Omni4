# OmniFile F3.1 — Error Register

| ID | Priority | Finding | Resolution | Status |
|---|---|---|---|---|
| OMNI-F3.1-001 | P0 | APKTool decode joined untrusted ZIP entry names directly to the output directory, permitting Zip Slip path traversal. | Added strict entry-name validation, canonical containment checks, preflight validation of all central-directory entries before output creation, and validation again at write time. Added regression tests. | FIXED — component harness PASS; Android Gradle regression test pending. |
| OMNI-F3.1-ENV-001 | Environment blocker | Android Gradle test tasks could not start because Gradle 8.10.2 could not be downloaded (`UnknownHostException: services.gradle.org`). | No source workaround applied. Requires an environment with the Gradle distribution cached or network access, plus Android SDK. | OPEN / BLOCKED ENVIRONMENT |
| OMNI-F3.1-ENV-002 | Environment blocker | Device/emulator verification unavailable (Android SDK/ADB not present). | Requires Android SDK and a test device or emulator. | OPEN / BLOCKED ENVIRONMENT |

No issue is marked VERIFIED for the full Android build/test environment. The P0 source fix passed the standalone component harness, while production Gradle verification remains pending.
