# OmniFile UI Design System

- Bright white / soft lavender surfaces.
- Violet dan electric blue sebagai warna utama.
- Rounded cards (18–24dp).
- Gradient hero banner.
- Bottom navigation: Beranda, Tools, File Manager, Proyek, Lainnya.
- Tools ditampilkan dalam grid dua kolom.
- Tidak menggunakan desain file manager klasik yang padat dan monokrom.

## Product policy
- Semua fitur aplikasi tersedia gratis.
- Tidak ada login, registrasi, profil akun, paywall, atau langganan.
- Pengaturan dan proyek disimpan secara lokal di perangkat.
- Tidak ada AI Studio pada navigasi maupun fitur aplikasi.

Warna dasar:
- Violet: #673DE6
- Blue: #168BFF
- Ink: #17143A
- Muted: #77758D
- Page: #F7F7FC
