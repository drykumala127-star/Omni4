# OmniFile — Android Studio Starter

Starter project untuk satu aplikasi Android modular dengan UI premium ungu-biru,
bottom navigation lima tab, halaman Tools berbentuk grid, dan fondasi Engine Registry.

## Buka proyek
1. Ekstrak ZIP.
2. Buka folder `OmniFile-Starter` melalui Android Studio.
3. Gunakan JDK 17.
4. Sinkronkan Gradle.
5. Jalankan konfigurasi `app`.

## Catatan
- Ini adalah starter UI dan arsitektur, belum berisi implementasi penuh APKTool/JADX.
- Modul engine saat ini menyediakan titik integrasi dan kontrak API.
- Integrasi engine nyata perlu dilakukan satu per satu, termasuk audit lisensi dan
  penyesuaian dependensi yang kompatibel dengan Android.
- `arm64-v8a` disiapkan sebagai ABI utama; belum ada binary native pihak ketiga.
- API 26 adalah minimum awal desain. Uji kembali pada versi Android target proyek.

## Modul
- `app`: aplikasi utama dan UI Compose.
- `core:engine-api`: kontrak engine.
- `core:workspace`: model workspace proyek.
- `feature:filemanager`: model fitur file manager.
- `feature:toolkit`: katalog tool.
- `engines:*`: adapter placeholder untuk engine yang akan diintegrasikan.


## Native ARM64 scaffold
- `native/CMakeLists.txt` builds `libomnifile_native.so`.
- App ABI filter is currently `arm64-v8a`.
- `NativeBridge.kt` exposes a minimal JNI test bridge.
- Android NDK and CMake must be installed through Android Studio SDK Manager.


## Product decisions
- AI Studio removed.
- Account/profile/subscription screens removed.
- No login or registration flow.
- All included features are intended to be free.
- Local-first project and workspace model.
- Bottom navigation: Beranda, Tools, File Manager, Proyek, Lainnya.
