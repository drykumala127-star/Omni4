#include <jni.h>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_omnifile_app_NativeBridge_nativeVersion(JNIEnv* env, jobject /* thiz */) {
    return env->NewStringUTF("OmniFile Native Runtime 0.1.0");
}
