package com.omnifile.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.viewmodel.compose.viewModel
import com.omnifile.feature.filemanager.viewmodel.FileManagerViewModel
import com.omnifile.feature.filemanager.ui.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Violet = Color(0xFF673DE6)
private val Blue = Color(0xFF168BFF)
private val Ink = Color(0xFF17143A)
private val Muted = Color(0xFF77758D)
private val Page = Color(0xFFF7F7FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OmniFileApp() }
    }
}

private data class TabItem(val title: String, val icon: ImageVector)
private val tabs = listOf(
    TabItem("Beranda", Icons.Default.Home),
    TabItem("Tools", Icons.Default.Build),
    TabItem("File Manager", Icons.Default.Folder),
    TabItem("Proyek", Icons.Default.Workspaces),
    TabItem("Lainnya", Icons.Default.GridView)
)

@Composable
private fun OmniFileApp() {
    var selected by remember { mutableIntStateOf(0) }
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Violet,
            secondary = Blue,
            background = Page,
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Page,
            bottomBar = {
                NavigationBar(containerColor = Color.White, tonalElevation = 10.dp) {
                    tabs.forEachIndexed { index, tab ->
                        NavigationBarItem(
                            selected = selected == index,
                            onClick = { selected = index },
                            icon = { Icon(tab.icon, contentDescription = tab.title) },
                            label = { Text(tab.title, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Violet,
                                selectedTextColor = Violet,
                                indicatorColor = Color(0xFFEDE7FF),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when (selected) {
                0 -> HomeScreen(Modifier.padding(padding))
                1 -> ToolsScreen(Modifier.padding(padding))
                2 -> FileManagerScreen(Modifier.padding(padding))
                3 -> ProjectsScreen(Modifier.padding(padding))
                else -> MoreScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
private fun ScreenColumn(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        content = content
    )
}

@Composable
private fun Header(title: String, subtitle: String? = null, icon: ImageVector = Icons.Default.AutoAwesome) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(top = 18.dp)) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(15.dp))
                .background(Brush.linearGradient(listOf(Violet, Blue))),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Color.White) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
            if (subtitle != null) Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, null, tint = Ink) }
    }
}

@Composable
private fun GradientBanner(title: String, subtitle: String, action: String) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF24116C), Violet, Blue)))
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 26.sp)
        Text(subtitle, color = Color.White.copy(alpha = .88f), fontSize = 12.sp)
        Surface(shape = CircleShape, color = Color.White) {
            Text(action, color = Violet, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                modifier = Modifier.clickable { }.padding(horizontal = 16.dp, vertical = 9.dp))
        }
    }
}

@Composable
private fun SectionTitle(title: String, action: String = "Lihat Semua") {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(action, color = Violet, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun HomeScreen(modifier: Modifier = Modifier) {
    ScreenColumn(modifier) {
        Header("OmniFile", "File Manager & Android Development Toolkit", Icons.Default.FolderSpecial)
        GradientBanner("Explore Unlimited Possibilities", "Professional tools for Android development in one workspace.", "Get Started  →")
        SectionTitle("Quick Actions")
        val quick = listOf(
            Tool("File Manager", "Kelola file dengan mudah", Icons.Default.Folder, Color(0xFFFFA126)),
            Tool("APK Analyzer", "Analisis APK secara detail", Icons.Default.Android, Color(0xFF18A86B)),
            Tool("DEX Explorer", "Jelajahi file DEX", Icons.Default.Code, Blue),
            Tool("Editor", "Edit kode dan resource", Icons.Default.Edit, Color(0xFFFF5D67))
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.height(112.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            userScrollEnabled = false
        ) { items(quick) { QuickAction(it) } }
        SectionTitle("Proyek Terakhir")
        ProjectRow("MyApp.apk", "2.4 MB  ·  APK Project", Icons.Default.Android)
        ProjectRow("StudioProject", "8.7 MB  ·  Development Project", Icons.Default.FolderCode)
        SectionTitle("Status Sistem", "Semua normal")
        Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFFE5F8EF)) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF159B61))
                Spacer(Modifier.width(9.dp))
                Text("Semua sistem berjalan normal", color = Color(0xFF167A50), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

private data class Tool(val name: String, val desc: String, val icon: ImageVector, val tint: Color)

@Composable
private fun QuickAction(tool: Tool) {
    Surface(shape = RoundedCornerShape(18.dp), color = Color.White, shadowElevation = 2.dp) {
        Column(Modifier.fillMaxSize().clickable { }.padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(tool.icon, null, tint = tool.tint, modifier = Modifier.size(28.dp))
            Spacer(Modifier.height(4.dp))
            Text(tool.name, fontSize = 10.sp, color = Ink, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ProjectRow(name: String, detail: String, icon: ImageVector) {
    Surface(shape = RoundedCornerShape(17.dp), color = Color.White, shadowElevation = 1.dp) {
        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Violet, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, color = Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(detail, color = Muted, fontSize = 10.sp)
            }
            Icon(Icons.Default.MoreVert, null, tint = Muted)
        }
    }
}

@Composable
private fun ToolsScreen(modifier: Modifier = Modifier) {
    val tools = listOf(
        Tool("APKTool", "Decode & rebuild APK", Icons.Default.Inventory2, Violet),
        Tool("JADX", "DEX ke Java source", Icons.Default.Code, Blue),
        Tool("APK Editor", "Edit struktur APK", Icons.Default.EditNote, Color(0xFFE95A7B)),
        Tool("DEX Explorer", "Jelajahi classes.dex", Icons.Default.DataObject, Violet),
        Tool("Smali Editor", "Lihat & edit Smali", Icons.Default.Terminal, Blue),
        Tool("XML Editor", "Edit format XML", Icons.Default.Code, Color(0xFF13A67A)),
        Tool("APK Signer", "Tanda tangani APK", Icons.Default.VerifiedUser, Color(0xFFEE9A2C)),
        Tool("ZIP Tools", "Buat & ekstrak arsip", Icons.Default.FolderZip, Blue),
        Tool("Hash Tools", "MD5, SHA-1, SHA-256", Icons.Default.Tag, Color(0xFF17A77A)),
        Tool("Manifest Editor", "Kelola manifest", Icons.Default.Description, Violet),
        Tool("SQLite Browser", "Jelajahi database", Icons.Default.Storage, Blue),
        Tool("Hex Editor", "Edit data hexadecimal", Icons.Default.Memory, Color(0xFFE95A7B))
    )
    ScreenColumn(modifier) {
        Header("Tools", "Alat lengkap untuk kebutuhan pengembangan Android", Icons.Default.Build)
        OutlinedTextField(
            value = "", onValueChange = {}, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Cari tools...") }, leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(18.dp), singleLine = true
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.height(780.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            userScrollEnabled = false
        ) { items(tools) { ToolCard(it) } }
        GradientBanner("Tools Professional", "Semua kebutuhan pengembangan dalam satu aplikasi.", "Jelajahi Tools →")
    }
}

@Composable
private fun ToolCard(tool: Tool) {
    Surface(shape = RoundedCornerShape(22.dp), color = Color.White, shadowElevation = 2.dp) {
        Column(
            Modifier.fillMaxWidth().height(132.dp).clickable { }.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(Modifier.size(43.dp).clip(RoundedCornerShape(14.dp)).background(
                Brush.linearGradient(listOf(tool.tint.copy(alpha = .18f), Blue.copy(alpha = .10f)))
            ), contentAlignment = Alignment.Center) {
                Icon(tool.icon, null, tint = tool.tint, modifier = Modifier.size(25.dp))
            }
            Spacer(Modifier.height(9.dp))
            Text(tool.name, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
            Text(tool.desc, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun FileManagerScreen(
    modifier: Modifier = Modifier,
    fileManagerViewModel: FileManagerViewModel = viewModel()
) {
    val uiState by fileManagerViewModel.uiState.collectAsState()

    val safLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            fileManagerViewModel.onDirectoryGranted(treeUri)
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        ScreenColumn {
            Header("File Manager", "Kelola file dan folder perangkat secara nyata", Icons.Default.Folder)

            // Storage Header Card
            Surface(shape = RoundedCornerShape(18.dp), color = Color.White, shadowElevation = 1.dp) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Penyimpanan Perangkat", color = Ink, fontWeight = FontWeight.Bold)
                            Text(
                                text = if (uiState.hasSafPermission) "Akses SAF Aktif (Persistable)" else "Pilih Folder Melalui SAF",
                                color = Muted,
                                fontSize = 11.sp
                            )
                        }
                        Button(
                            onClick = { safLauncher.launch(null) },
                            colors = ButtonDefaults.buttonColors(containerColor = Violet),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (uiState.hasSafPermission) "Ganti Folder" else "Pilih Folder", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            if (!uiState.hasSafPermission) {
                StoragePermissionPrompt(
                    onGrantClicked = { safLauncher.launch(null) }
                )
            } else {
                // Search & Category Filters Bar
                SearchFilterBar(
                    searchQuery = uiState.searchQuery,
                    onQueryChange = { fileManagerViewModel.onSearchQueryChange(it) },
                    activeFilter = uiState.activeCategoryFilter,
                    onFilterSelect = { fileManagerViewModel.onCategoryFilterSelect(it) },
                    onSortClick = { fileManagerViewModel.openSortSheet() }
                )

                // Breadcrumbs Navigation Bar
                if (uiState.breadcrumbs.isNotEmpty() && uiState.searchQuery.isBlank()) {
                    BreadcrumbBar(
                        breadcrumbs = uiState.breadcrumbs,
                        onBreadcrumbClicked = { crumb ->
                            fileManagerViewModel.navigateTo(crumb.uri, crumb.title)
                        }
                    )
                }

                // Action Bar for Multi-selection and General Actions
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (uiState.isMultiSelectMode) Color(0xFFEDE8FF) else Color.White,
                    shadowElevation = 1.dp
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (uiState.isMultiSelectMode) {
                            Text(
                                text = uiState.selectedCountDisplay,
                                color = Violet,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { fileManagerViewModel.selectAll() }) {
                                    Icon(Icons.Default.SelectAll, contentDescription = "Pilih Semua", tint = Violet)
                                }
                                if (uiState.selectedUris.size == 1) {
                                    val selectedEntry = uiState.items.find { it.uri == uiState.selectedUris.first() }
                                    if (selectedEntry != null) {
                                        IconButton(onClick = { fileManagerViewModel.openRenameDialog(selectedEntry) }) {
                                            Icon(Icons.Default.Edit, contentDescription = "Ganti Nama", tint = Violet)
                                        }
                                    }
                                }
                                IconButton(onClick = { fileManagerViewModel.copySelected() }) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Salin", tint = Violet)
                                }
                                IconButton(onClick = { fileManagerViewModel.cutSelected() }) {
                                    Icon(Icons.Default.ContentCut, contentDescription = "Pindahkan", tint = Violet)
                                }
                                IconButton(onClick = { fileManagerViewModel.openDeleteConfirmation() }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = MaterialTheme.colorScheme.error)
                                }
                                IconButton(onClick = { fileManagerViewModel.clearSelection() }) {
                                    Icon(Icons.Default.Close, contentDescription = "Batal", tint = Muted)
                                }
                            }
                        } else {
                            Text(
                                text = if (uiState.searchQuery.isNotBlank()) "Hasil Pencarian (${uiState.items.size})" else "Daftar File (${uiState.items.size})",
                                color = Ink,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { fileManagerViewModel.openCreateFolderDialog() }) {
                                    Icon(Icons.Default.CreateNewFolder, contentDescription = "Folder Baru", tint = Violet)
                                }
                                IconButton(onClick = { fileManagerViewModel.refresh() }) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Violet)
                                }
                            }
                        }
                    }
                }

                // Clipboard Paste Bar
                if (uiState.clipboardUris.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xFFE5F8EF),
                        shadowElevation = 2.dp
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${uiState.clipboardUris.size} item siap di-${if (uiState.isMoveOperation) "pindahkan" else "salin"}",
                                color = Color(0xFF167A50),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp
                            )
                            Button(
                                onClick = { fileManagerViewModel.pasteClipboard() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF159B61)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Tempel Di Sini", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // State Display: Loading / Empty / Dynamic Items
                if (uiState.isLoading) {
                    Box(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = Violet)
                    }
                } else if (uiState.items.isEmpty()) {
                    EmptyFolderView(
                        message = uiState.errorMessage ?: if (uiState.searchQuery.isNotBlank()) "Tidak ada file yang cocok dengan '${uiState.searchQuery}'" else "Folder ini kosong atau belum memiliki file yang dapat dibaca."
                    )
                } else {
                    uiState.items.forEach { file ->
                        FileItemRow(
                            entry = file,
                            isSelected = uiState.selectedUris.contains(file.uri),
                            onClick = {
                                if (uiState.isMultiSelectMode) {
                                    fileManagerViewModel.toggleSelection(file.uri)
                                } else if (file.isDirectory) {
                                    fileManagerViewModel.navigateTo(file.uri, file.name)
                                } else {
                                    fileManagerViewModel.toggleSelection(file.uri)
                                }
                            },
                            onLongClick = {
                                fileManagerViewModel.toggleSelection(file.uri)
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
        }

        // Dialogs Overlay
        if (uiState.isDeleteConfirmationOpen) {
            val selectedNames = uiState.items
                .filter { uiState.selectedUris.contains(it.uri) }
                .map { it.name }

            ConfirmDeleteDialog(
                itemCount = uiState.selectedUris.size,
                itemNames = selectedNames,
                onConfirm = { fileManagerViewModel.executeDelete() },
                onDismiss = { fileManagerViewModel.closeDeleteConfirmation() }
            )
        }

        if (uiState.isRenameDialogOpen && uiState.renameTargetEntry != null) {
            RenameDialog(
                initialName = uiState.renameTargetEntry!!.name,
                onConfirm = { newName -> fileManagerViewModel.rename(newName) },
                onDismiss = { fileManagerViewModel.closeRenameDialog() }
            )
        }

        if (uiState.isCreateFolderDialogOpen) {
            CreateFolderDialog(
                onConfirm = { folderName -> fileManagerViewModel.createFolder(folderName) },
                onDismiss = { fileManagerViewModel.closeCreateFolderDialog() }
            )
        }

        if (uiState.activeOperationProgress != null) {
            OperationProgressDialog(
                progress = uiState.activeOperationProgress!!,
                onCancel = { fileManagerViewModel.cancelActiveOperation() }
            )
        }

        if (uiState.isSortSheetOpen) {
            SortBottomSheet(
                currentSortOrder = uiState.sortOrder,
                onSortOrderChange = { fileManagerViewModel.setSortOrder(it) },
                onDismiss = { fileManagerViewModel.closeSortSheet() }
            )
        }
    }
}

@Composable
private fun ProjectsScreen(modifier: Modifier = Modifier) {
    ScreenColumn(modifier) {
        Header("Proyek", "Semua proyek pengolahan APK dan file", Icons.Default.Workspaces)
        GradientBanner("Workspace Terpadu", "Kelola hasil decode, source, resource, build, dan signing dalam satu tempat.", "Buat Proyek →")
        SectionTitle("Proyek terbaru")
        ProjectRow("MyApp.apk", "APK · Terakhir dibuka", Icons.Default.Android)
        ProjectRow("StudioProject", "Workspace · Development", Icons.Default.Folder)
        ProjectRow("Sample-Dex", "DEX · Analisis bytecode", Icons.Default.DataObject)
        ProjectRow("Resource-Edit", "Resource · XML dan gambar", Icons.Default.Edit)
    }
}

@Composable
private fun MoreScreen(modifier: Modifier = Modifier) {
    ScreenColumn(modifier) {
        Header("Lainnya", "Pengaturan dan fitur tambahan", Icons.Default.GridView)
        GradientBanner("OmniFile Toolkit", "Semua fitur tersedia gratis. Tanpa akun, login, atau langganan.", "Jelajahi Tools →")
        listOf(
            "Pengaturan Aplikasi" to "Preferensi dan perilaku aplikasi",
            "Tema & Tampilan" to "Terang, gelap, atau otomatis",
            "Task Manager" to "Pantau proses engine",
            "Workspace & Backup" to "Kelola proyek dan cadangan",
            "Keamanan & Privasi" to "Izin penyimpanan dan data lokal",
            "Lisensi Open Source" to "Informasi lisensi komponen",
            "Tentang OmniFile" to "Versi aplikasi dan informasi proyek"
        ).forEach { (title, detail) ->
            ProjectRow(title, detail, Icons.Default.Settings)
        }
        Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFFEDE8FF)) {
            Text(
                "Gratis untuk digunakan • Tidak perlu login • Tidak ada paket berlangganan",
                modifier = Modifier.padding(14.dp),
                color = Violet, fontWeight = FontWeight.Bold, fontSize = 11.sp
            )
        }
    }
}
