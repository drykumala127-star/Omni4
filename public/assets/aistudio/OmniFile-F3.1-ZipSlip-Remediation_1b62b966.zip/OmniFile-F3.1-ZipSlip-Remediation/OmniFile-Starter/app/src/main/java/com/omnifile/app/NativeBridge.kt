package com.omnifile.app

object NativeBridge {
    init {
        System.loadLibrary("omnifile_native")
    }

    external fun nativeVersion(): String
}
