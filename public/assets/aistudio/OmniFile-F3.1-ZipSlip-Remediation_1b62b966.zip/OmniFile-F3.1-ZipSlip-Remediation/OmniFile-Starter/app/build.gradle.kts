plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.omnifile.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.omnifile.app"
        minSdk = 26
        targetSdk = 35
    ndk { abiFilters += listOf("arm64-v8a") }
        versionCode = 1
        versionName = "0.1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures { compose = true }
    externalNativeBuild {
        cmake { path = file("../native/CMakeLists.txt"); version = "3.22.1" }
    }
    packaging {
        jniLibs { useLegacyPackaging = false }
    }
}

dependencies {
    implementation(project(":core:engine-api"))
    implementation(project(":core:workspace"))
    implementation(project(":feature:filemanager"))
    implementation(project(":feature:toolkit"))
    implementation(project(":engines:apktool"))
    implementation(project(":engines:jadx"))
    implementation(project(":engines:smali"))

    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.8.5")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    testImplementation("junit:junit:4.13.2")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
