package com.omnifile.app

import com.omnifile.feature.toolkit.build.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * End-to-end unit tests verifying Stage 5 APK Build System:
 * - 5.4 APK Rebuild
 * - 5.5 APK Signing (v1/v2 Schemes)
 * - 5.6 Signature Verification
 * - 5.7 Build Validation & Alignment
 * - 5.8 Build History Tracking
 */
class ApkBuildSystemTest {

    private val tempDir: File by lazy {
        val f = File(System.getProperty("java.io.tmpdir"), "build_test_" + UUID.randomUUID())
        f.mkdirs()
        f
    }

    @Test
    fun testApkSigningAndSignatureVerification() {
        val unsignedApk = File(tempDir, "unsigned.apk")
        ZipOutputStream(unsignedApk.outputStream()).use { zos ->
            zos.putNextEntry(ZipEntry("AndroidManifest.xml"))
            zos.write("<manifest/>".toByteArray())
            zos.closeEntry()
            zos.putNextEntry(ZipEntry("classes.dex"))
            zos.write(ByteArray(112))
            zos.closeEntry()
        }

        val signedApk = File(tempDir, "signed.apk")
        val signResult = ApkSignerEngine.signApk(unsignedApk, signedApk)
        assertTrue("Signing must succeed", signResult)
        assertTrue(signedApk.exists())

        val verifyResult = ApkSignerEngine.verifySignature(signedApk)
        assertTrue("Signature verification must pass", verifyResult.isValid)
        assertTrue("Must have v1 scheme", verifyResult.hasV1Signature)
        assertTrue("Must have v2 scheme", verifyResult.hasV2Signature)
    }

    @Test
    fun testApkAlignmentValidation() {
        val testApk = File(tempDir, "align_test.apk")
        ZipOutputStream(testApk.outputStream()).use { zos ->
            val entry = ZipEntry("res/raw/data.bin")
            zos.putNextEntry(entry)
            zos.write(ByteArray(100))
            zos.closeEntry()
        }

        val report = ApkAlignmentValidator.verifyAlignment(testApk)
        assertNotNull(report)
        assertEquals(4, report.alignmentBoundary)
    }

    @Test
    fun testBuildHistoryTracker() {
        val historyFile = File(tempDir, "build_history.json")
        val tracker = BuildHistoryTracker(historyFile)

        val record = BuildRecord(
            projectName = "DemoApp",
            outputApkPath = "/path/to/demo.apk",
            sizeBytes = 1048576L,
            sha256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            isSigned = true,
            durationMillis = 1500L,
            success = true,
            statusMessage = "OK"
        )

        tracker.recordBuild(record)
        val list = tracker.getRecords()
        assertEquals(1, list.size)
        assertEquals("DemoApp", list[0].projectName)
        assertEquals(record.sha256, list[0].sha256)
    }

    @Test
    fun testFullApkBuildPipeline() = runBlocking {
        val projectDir = File(tempDir, "proj_root")
        val decodedDir = File(projectDir, "decoded")
        decodedDir.mkdirs()

        // Setup mock decoded files
        File(decodedDir, "AndroidManifest.xml").writeText("<manifest package=\"com.test\"/>")
        File(decodedDir, "classes.dex").writeBytes(ByteArray(112))

        val outputDir = File(tempDir, "output_signed")
        val historyFile = File(projectDir, "build_history.json")
        val tracker = BuildHistoryTracker(historyFile)

        val result = ApkBuildPipeline.executeFullBuild(projectDir, "MyTestApp", outputDir, tracker)
        assertTrue("Full build must succeed", result.success)
        assertNotNull(result.outputSignedApkFile)
        assertTrue(result.outputSignedApkFile!!.exists())
        assertTrue(result.sha256.isNotEmpty())
        assertTrue(result.signatureResult?.isValid == true)

        val records = tracker.getRecords()
        assertEquals(1, records.size)
    }
}
