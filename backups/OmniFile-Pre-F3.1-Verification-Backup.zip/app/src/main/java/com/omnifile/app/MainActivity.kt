package com.omnifile.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.omnifile.app.ui.components.AppTopBar
import com.omnifile.app.ui.dialogs.EngineTerminalDialog
import com.omnifile.app.ui.dialogs.ProductionChecklistDialog
import com.omnifile.app.ui.dialogs.RoadmapStagesDialog
import com.omnifile.app.ui.screens.*
import com.omnifile.app.ui.theme.*
import com.omnifile.app.ui.tools.ToolDefinition
import com.omnifile.app.ui.tools.ToolDialog
import com.omnifile.feature.filemanager.ui.*
import com.omnifile.feature.filemanager.viewmodel.FileManagerViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            OmniFileApp()
        }
    }
}

private data class TabItem(val title: String, val icon: ImageVector, val tag: String)

private val tabs = listOf(
    TabItem("Beranda", Icons.Default.Home, "tab_home"),
    TabItem("Tools", Icons.Default.Build, "tab_tools"),
    TabItem("Files", Icons.Default.Folder, "tab_files"),
    TabItem("Proyek", Icons.Default.Workspaces, "tab_projects"),
    TabItem("Lainnya", Icons.Default.GridView, "tab_more")
)

@Composable
private fun OmniFileApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    var currentTheme by remember { mutableStateOf(AppThemeMode.VIOLET) }
    var currentLang by remember { mutableStateOf("id") }

    // Dialog state
    var selectedTool by remember { mutableStateOf<ToolDefinition?>(null) }
    var isTerminalOpen by remember { mutableStateOf(false) }
    var isRoadmapOpen by remember { mutableStateOf(false) }
    var isHardeningOpen by remember { mutableStateOf(false) }

    // Handle back button: close modals first, or return to home tab
    BackHandler(enabled = selectedTool != null || isTerminalOpen || isRoadmapOpen || isHardeningOpen || selectedTab != 0) {
        when {
            selectedTool != null -> selectedTool = null
            isTerminalOpen -> isTerminalOpen = false
            isRoadmapOpen -> isRoadmapOpen = false
            isHardeningOpen -> isHardeningOpen = false
            selectedTab != 0 -> selectedTab = 0
        }
    }

    OmniFileTheme(themeMode = currentTheme) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                AppTopBar(
                    title = "OmniFile",
                    subtitle = when (selectedTab) {
                        0 -> "File Manager & Android Toolkit"
                        1 -> "12 Alat Reverse Engineering"
                        2 -> "Penyimpanan Berkas Nyata & SAF"
                        3 -> "Workspace Manajemen Proyek"
                        else -> "Pengaturan Sistem & Privasi"
                    },
                    onOpenTerminal = { isTerminalOpen = true },
                    onOpenRoadmap = { isRoadmapOpen = true },
                    onOpenHardening = { isHardeningOpen = true },
                    currentLang = currentLang,
                    onToggleLang = { currentLang = if (currentLang == "id") "en" else "id" }
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    modifier = Modifier.navigationBarsPadding().testTag("bottom_nav_bar")
                ) {
                    tabs.forEachIndexed { index, tab ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Icon(tab.icon, contentDescription = tab.title) },
                            label = { Text(tab.title, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                            modifier = Modifier.testTag(tab.tag),
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                unselectedTextColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        )
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when (selectedTab) {
                    0 -> HomeScreen(
                        onNavigateToTab = { selectedTab = it },
                        onOpenTool = { selectedTool = it }
                    )
                    1 -> ToolsScreen(
                        onOpenTool = { selectedTool = it }
                    )
                    2 -> FileManagerTab()
                    3 -> ProjectsScreen(
                        onOpenProject = { proj ->
                            selectedTool = ToolDefinition(
                                id = "apktool",
                                name = "APKTool: ${proj.name}",
                                desc = "Analisis dan modifikasi proyek ${proj.name}",
                                category = "reversing",
                                tint = VioletPrimary
                            )
                        }
                    )
                    else -> MoreScreen(
                        currentTheme = currentTheme,
                        onSelectTheme = { currentTheme = it },
                        currentLang = currentLang,
                        onToggleLang = { currentLang = if (currentLang == "id") "en" else "id" },
                        onOpenTerminal = { isTerminalOpen = true },
                        onOpenHardening = { isHardeningOpen = true },
                        onOpenRoadmap = { isRoadmapOpen = true }
                    )
                }
            }
        }

        // Tool Modal Dialog
        selectedTool?.let { tool ->
            ToolDialog(
                tool = tool,
                onDismiss = { selectedTool = null }
            )
        }

        // Terminal CLI Modal
        if (isTerminalOpen) {
            EngineTerminalDialog(onDismiss = { isTerminalOpen = false })
        }

        // Hardening Checklist Modal
        if (isHardeningOpen) {
            ProductionChecklistDialog(onDismiss = { isHardeningOpen = false })
        }

        // Roadmap Stages Modal
        if (isRoadmapOpen) {
            RoadmapStagesDialog(onDismiss = { isRoadmapOpen = false })
        }
    }
}

@Composable
private fun FileManagerTab(
    fileManagerViewModel: FileManagerViewModel = viewModel()
) {
    val uiState by fileManagerViewModel.uiState.collectAsState()

    val safLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            fileManagerViewModel.onDirectoryGranted(treeUri)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Storage Header Card
            Surface(
                shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = "Penyimpanan Perangkat",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (uiState.hasSafPermission) "Akses SAF Terverifikasi (Persistable)" else "Pilih Folder Melalui SAF",
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            fontSize = 11.sp
                        )
                    }
                    Button(
                        onClick = { safLauncher.launch(null) },
                        colors = ButtonDefaults.buttonColors(containerColor = VioletPrimary),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = if (uiState.hasSafPermission) "Ganti Folder" else "Pilih Folder",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (!uiState.hasSafPermission) {
                StoragePermissionPrompt(
                    onGrantClicked = { safLauncher.launch(null) }
                )
            } else {
                SearchFilterBar(
                    searchQuery = uiState.searchQuery,
                    onQueryChange = { fileManagerViewModel.onSearchQueryChange(it) },
                    activeFilter = uiState.activeCategoryFilter,
                    onFilterSelect = { fileManagerViewModel.onCategoryFilterSelect(it) },
                    onSortClick = { fileManagerViewModel.openSortSheet() }
                )

                if (uiState.breadcrumbs.isNotEmpty() && uiState.searchQuery.isBlank()) {
                    BreadcrumbBar(
                        breadcrumbs = uiState.breadcrumbs,
                        onBreadcrumbClicked = { crumb ->
                            fileManagerViewModel.navigateTo(crumb.uri, crumb.title)
                        }
                    )
                }

                Surface(
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                    color = if (uiState.isMultiSelectMode) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface,
                    shadowElevation = 1.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (uiState.isMultiSelectMode) uiState.selectedCountDisplay else "Daftar Berkas (${uiState.items.size})",
                            color = if (uiState.isMultiSelectMode) VioletPrimary else MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            IconButton(onClick = { fileManagerViewModel.openCreateFolderDialog() }) {
                                Icon(Icons.Default.CreateNewFolder, contentDescription = "Folder Baru", tint = VioletPrimary)
                            }
                            IconButton(onClick = { fileManagerViewModel.refresh() }) {
                                Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = VioletPrimary)
                            }
                        }
                    }
                }

                if (uiState.isLoading) {
                    Box(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp),
                        contentAlignment = androidx.compose.ui.Alignment.Center
                    ) {
                        CircularProgressIndicator(color = VioletPrimary)
                    }
                } else if (uiState.items.isEmpty()) {
                    EmptyFolderView(
                        message = uiState.errorMessage ?: if (uiState.searchQuery.isNotBlank()) "Tidak ada berkas yang cocok dengan '${uiState.searchQuery}'" else "Folder ini kosong atau belum memiliki berkas."
                    )
                } else {
                    androidx.compose.foundation.lazy.LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(uiState.items) { file ->
                            FileItemRow(
                                entry = file,
                                isSelected = uiState.selectedUris.contains(file.uri),
                                onClick = {
                                    if (uiState.isMultiSelectMode) {
                                        fileManagerViewModel.toggleSelection(file.uri)
                                    } else if (file.isDirectory) {
                                        fileManagerViewModel.navigateTo(file.uri, file.name)
                                    } else {
                                        fileManagerViewModel.toggleSelection(file.uri)
                                    }
                                },
                                onLongClick = {
                                    fileManagerViewModel.toggleSelection(file.uri)
                                }
                            )
                        }
                    }
                }
            }
        }

        // Operation Dialogs
        if (uiState.isDeleteConfirmationOpen) {
            val selectedNames = uiState.items
                .filter { uiState.selectedUris.contains(it.uri) }
                .map { it.name }

            ConfirmDeleteDialog(
                itemCount = uiState.selectedUris.size,
                itemNames = selectedNames,
                onConfirm = { fileManagerViewModel.executeDelete() },
                onDismiss = { fileManagerViewModel.closeDeleteConfirmation() }
            )
        }

        if (uiState.isRenameDialogOpen && uiState.renameTargetEntry != null) {
            RenameDialog(
                initialName = uiState.renameTargetEntry!!.name,
                onConfirm = { newName -> fileManagerViewModel.rename(newName) },
                onDismiss = { fileManagerViewModel.closeRenameDialog() }
            )
        }

        if (uiState.isCreateFolderDialogOpen) {
            CreateFolderDialog(
                onConfirm = { folderName -> fileManagerViewModel.createFolder(folderName) },
                onDismiss = { fileManagerViewModel.closeCreateFolderDialog() }
            )
        }

        if (uiState.isSortSheetOpen) {
            SortBottomSheet(
                currentSortOrder = uiState.sortOrder,
                onSortOrderChange = { fileManagerViewModel.setSortOrder(it) },
                onDismiss = { fileManagerViewModel.closeSortSheet() }
            )
        }
    }
}
