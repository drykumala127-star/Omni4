package com.omnifile.core.engineapi

import android.content.Context

data class EngineRequest(
    val inputPath: String,
    val outputPath: String? = null,
    val operation: String,
    val options: Map<String, String> = emptyMap()
)

data class EngineResult(
    val success: Boolean,
    val outputPath: String? = null,
    val message: String,
    val details: Map<String, String> = emptyMap()
)

interface ToolEngine {
    val id: String
    val displayName: String
    val version: String
    suspend fun initialize(context: Context)
    suspend fun execute(request: EngineRequest): EngineResult
    suspend fun shutdown()
}

class EngineRegistry {
    private val engines = linkedMapOf<String, ToolEngine>()
    fun register(engine: ToolEngine) { engines[engine.id] = engine }
    fun get(id: String): ToolEngine? = engines[id]
    fun all(): List<ToolEngine> = engines.values.toList()
}
